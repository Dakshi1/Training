import React from 'react';

// a new Component called AppHeader
const AppHeader = function (props) {

    return (
        <div>
            <h1>ToDo App</h1>
        </div>
    );
}

export default AppHeader;