import React, { Component } from 'react';

const defaultValues = { task: '' }
class ToDoForm extends Component {
    state = { ...defaultValues }

    tfChangeHandler = (evt) => {
        let { name, value } = evt.target;
        this.setState({ [name]: value });
    }

    submitHandler = (evt) => {
        // evt is the event object corresponding to the
        // submit event, fired when (1) you clicked the submit button
        // (2) you pressed enter key on any input elements
        evt.preventDefault(); // do not submit to HTTP SERVER
        this.props.addTask({ ...this.state });
        // clear the form elements by restting the state
        this.setState({ ...defaultValues });


    }
    render() {
        return (
            <div>
                <form onSubmit={this.submitHandler}>

                    <input type="text" id="task" autoFocus
                        value={this.state.task}
                        onChange={this.tfChangeHandler}
                        className="form-control" name="task" />

                    <button className="btn btn-primary">Save changes</button>
                </form>
            </div>
        );
    }
}

export default ToDoForm;