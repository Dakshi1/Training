import React from 'react';
import ToDo from './ToDo';


export default function (props) {

    // convert each contact in the array 'data' into a ContactCard component
    let output = props.tasksBucket.map((c) => <ToDo data={c}
        
        //editContact={props.editContact} 
        />);
    return (
        <div className="row">
            {output}
        </div>

    );
}