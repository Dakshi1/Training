import React, { Component } from 'react';

class ToDo extends Component {
    state = {}
    render() {
         let { _id,
             task } = this.props.data;
        return (
            <div className="col-sm-6 col-md-4">
                <div className="card">

                    <div className="card-body">
                        <h5 className="card-title">
                            { task }
                        </h5>

                        <button
                            /* onClick={() => {
                                 this.props.editContact(this.props.data);
                             }}*/
                            className="btn btn-link text-primary">open</button>
                        <button
                            /* onClick={() => {
                                 if (window.confirm('Are you sure to delete this?')) {
                                     this.props.deleteContact(_id);
                                 }
                             }}*/
                            className="btn btn-link text-danger">medium</button>


                    </div>
                </div >
            </div>
        );
    }
}

export default ToDo;