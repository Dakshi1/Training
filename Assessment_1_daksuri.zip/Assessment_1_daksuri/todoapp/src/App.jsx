import React, { Component } from 'react';
import ReactDOM from 'react-dom'
import AppHeader from './components/AppHeader'

import 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap';

import ToDoList from './components/ToDoList';
import ToDoForm from './components/ToDoForm';

var baseUrl = 'http://localhost:4000/api/todos/';

class App extends Component {
  state = { tasksBucket: [] }

  constructor() {
    super();
  }

  addTask = (task) => {
    const options = {
      method: 'POST',
      body: JSON.stringify(task),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    
    fetch(baseUrl, options)
       .then(resp => resp.json())
       .then(data => {
         let tasksBucket = [data, ...this.state.tasksBucket];
         this.setState({ tasksBucket });
       });
  }

  componentDidMount() {
    
    fetch(baseUrl)
      .then(resp => resp.json())
      .then(data => {
        this.setState({ tasksBucket: data })
      })
      .catch(err => console.log(err));
  }

  render() {
    return (
      <div>
        <AppHeader title="ToDo App" />
        <div className="container">
          <div className="column">
            <div >
              <ToDoForm addTask={this.addTask} />
            </div>
            <br /> <br />
            <div className="column">
              <ToDoList tasksBucket={this.state.tasksBucket} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));

